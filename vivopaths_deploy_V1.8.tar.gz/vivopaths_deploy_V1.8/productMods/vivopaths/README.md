# VIVOPaths

VIVOPaths ist eine Applikation zur Visualisierung von semantischen Verbindungen in Forschungsnetzwerken.

Das Projekt ist in einem frühen Stadium unter https://hornmo.github.io/vivopaths/ zu erreichen.