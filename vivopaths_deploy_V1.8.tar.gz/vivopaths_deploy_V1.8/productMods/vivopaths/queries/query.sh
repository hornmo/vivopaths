#!/bin/bash
#
# VIVOPaths data update
# * führt Fuseki-Abfragen durch
# * führt neue Daten zusammen
#
# @author Moritz.Horn@tib.eu
#

host=`uname -n`
whoami=`whoami`
user="vivo"
group="vivo"
vpath="$HOME/tomcat/webapps/vivo-test/vivopaths"
jpath="$HOME/src/jena-fuseki-1.1.1-vivo"

servername="http://localhost:2020"

# prüfe ob Benutzer korrekt
#
if test "$user" != "$whoami" ; then
    echo >&2 "ERROR: you are '$whoami' -- please login as '$user' to use this script"
    exit -1
fi
date +"*** %Y-%m-%d %H:%M:%S Update start"
if test "$(echo $jpath | tr -d '\r')";then
  if test "$(echo $vpath | tr -d '\r')";then
    cd "$HOME/src/jena-fuseki-1.1.1-vivo/"
    status=$(curl --write-out %{http_code} --silent --output /dev/null $servername)
    if [ ${status} -eq 200 ];then
      # SPARQL-Query für Schlagwörter
      "$(echo $jpath | tr -d '\r')"/s-query --service http://localhost:2020/ds/query --query="$(echo $vpath | tr -d '\r')/queries/keywords_query.rq" > "$(echo $vpath | tr -d '\r')/data/spql_keywords.json"
      if test $? -eq 0;then
	date +"*** %Y-%m-%d %H:%M:%S Schlagwörter aktualisiert"
      else
	date +"*** %Y-%m-%d %H:%M:%S Schlagwörter aktualisieren fehlgeschlagen!"
	exit -1
      fi
      
      # SPARQL-Query für Autoren
      "$(echo $jpath | tr -d '\r')"/s-query --service http://localhost:2020/ds/query --query="$(echo $vpath | tr -d '\r')/queries/persons_query.rq" > "$(echo $vpath | tr -d '\r')/data/spql_authors.json"
      if test $? -eq 0;then
	date +"*** %Y-%m-%d %H:%M:%S Autoren aktualisiert"
      else
	date +"*** %Y-%m-%d %H:%M:%S Autoren aktualisieren fehlgeschlagen!"
	exit -1
      fi

      # SPARQL-Query für Publikationen
      "$(echo $jpath | tr -d '\r')"/s-query --service http://localhost:2020/ds/query --query="$(echo $vpath | tr -d '\r')/queries/documents_query.rq" >  "$(echo $vpath | tr -d '\r')/data/spql_pubs.json"
      if test $? -eq 0;then
	date +"*** %Y-%m-%d %H:%M:%S Publikationen aktualisiert"
      else
	date +"*** %Y-%m-%d %H:%M:%S Publikationen aktualisieren fehlgeschlagen!"
	exit -1
      fi

      # SPARQL-Query für Projekte
      "$(echo $jpath | tr -d '\r')"/s-query --service http://localhost:2020/ds/query --query="$(echo $vpath | tr -d '\r')/queries/projects_query.rq" > "$(echo $vpath | tr -d '\r')/data/spql_projects.json"
      if test $? -eq 0;then
	date +"*** %Y-%m-%d %H:%M:%S Projekte aktualisiert"
      else
	date +"*** %Y-%m-%d %H:%M:%S Projekte aktualisieren fehlgeschlagen!"
	exit -1
      fi

      # Füge alle JSON-Dateien zusammen
      if test -x "$(echo $vpath | tr -d '\r')/data";then
	cd "$(echo $vpath | tr -d '\r')/data"
	perl merge.pl && date +"*** %Y-%m-%d %H:%M:%S Daten in merged_data.json zusammengeführt" && exit 0 || echo "Zusammenführen fehlgeschlagen"
      else
	echo "Zielpfad nicht gefunden"
	exit -1
      fi
    else
      echo >&2 "Verbindung zum Fuseki-Server konnte nicht hergestellt werden: Errorcode ${status}"
      exit -1
    fi
  else
    echo >&2 "VIVOPaths-Verzeichnis nicht gefunden."
    exit -1
  fi
else
  echo  >&2 "Fuseki-Verzeichnis nicht gefunden."
  exit -1
fi
